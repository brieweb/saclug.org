# Introduction to ring-2

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
