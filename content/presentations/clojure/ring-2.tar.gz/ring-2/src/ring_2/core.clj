(ns ring-2.core
  (:use ring.adapter.jetty)
  (:require [clojure.data.json :as json]
            [compojure.route :refer :all]
            [compojure.route :as route])
  (:gen-class))

(defroutes app
  (GET "/:number" [number] (str "Number is: " number))
  (route/not-found "404"))


(defn handler [request]
  (ring.util.response/response
   (json/write-str [{:message "Hello, world!"}
                    {:remote-address (:remote-addr request)}
                    {:map {:first "hello"}}
                    {:message "Goodbye, world!"}])))

(defn -main
  "I don't do a whole lot ... yet."
  [& args]
  (do (println "Server up!")
      (run-jetty handler {:port 3000})))
